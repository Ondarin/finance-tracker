const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const swaggerUi = require('swagger-ui-express');
const openapi = require('./openapi.json');

const PORT = process.env.PORT || 4000;
const DB_FILE = path.join(__dirname, 'db.json');

const seed = {
  budget: { monthlyLimit: 20000, savingsGoal: 5000 },
  transactions: [
    { id: 1, type: 'income', category: 'Зарплата', amount: 25000, description: 'Зарплата', date: '2026-10-01' },
    { id: 2, type: 'expense', category: 'Їжа', amount: 3200, description: 'Продукти', date: '2026-10-03' },
    { id: 3, type: 'expense', category: 'Транспорт', amount: 800, description: 'Проїзний', date: '2026-10-05' },
    { id: 4, type: 'expense', category: 'Розваги', amount: 1500, description: 'Кіно та кафе', date: '2026-10-06' },
  ],
};

const load = () => {
  if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify(seed, null, 2));
  return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
};
const save = (db) => fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));

const validate = (b) => {
  if (!['income', 'expense'].includes(b.type)) return 'type має бути income або expense';
  if (typeof b.amount !== 'number' || b.amount <= 0) return 'amount має бути додатним числом';
  if (!b.category) return "category є обов'язковим";
  if (!b.date) return "date є обов'язковим";
  return null;
};

const app = express();
app.use(cors());
app.use(express.json());
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(openapi));

app.get('/api/transactions', (req, res) => {
  const { type, category } = req.query;
  let list = load().transactions;
  if (type) list = list.filter((t) => t.type === type);
  if (category) list = list.filter((t) => t.category === category);
  res.json(list.sort((a, b) => b.date.localeCompare(a.date)));
});

app.post('/api/transactions', (req, res) => {
  const err = validate(req.body);
  if (err) return res.status(400).json({ message: err });
  const db = load();
  const { type, category, amount, description = '', date } = req.body;
  const tx = { id: Date.now(), type, category, amount, description, date };
  db.transactions.push(tx);
  save(db);
  res.status(201).json(tx);
});

app.put('/api/transactions/:id', (req, res) => {
  const err = validate(req.body);
  if (err) return res.status(400).json({ message: err });
  const db = load();
  const i = db.transactions.findIndex((t) => t.id === Number(req.params.id));
  if (i === -1) return res.status(404).json({ message: 'Транзакцію не знайдено' });
  db.transactions[i] = { ...db.transactions[i], ...req.body, id: db.transactions[i].id };
  save(db);
  res.json(db.transactions[i]);
});

app.delete('/api/transactions/:id', (req, res) => {
  const db = load();
  const before = db.transactions.length;
  db.transactions = db.transactions.filter((t) => t.id !== Number(req.params.id));
  if (db.transactions.length === before) return res.status(404).json({ message: 'Транзакцію не знайдено' });
  save(db);
  res.status(204).end();
});

app.get('/api/budget', (req, res) => res.json(load().budget));

app.put('/api/budget', (req, res) => {
  const { monthlyLimit, savingsGoal } = req.body;
  if (![monthlyLimit, savingsGoal].every((v) => typeof v === 'number' && v >= 0))
    return res.status(400).json({ message: 'monthlyLimit та savingsGoal мають бути числами ≥ 0' });
  const db = load();
  db.budget = { monthlyLimit, savingsGoal };
  save(db);
  res.json(db.budget);
});

app.listen(PORT, () => {
  console.log(`API: http://localhost:${PORT}/api  |  Swagger: http://localhost:${PORT}/api-docs`);
});
