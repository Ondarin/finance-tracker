export const CATEGORIES = {
  expense: ['Їжа', 'Транспорт', 'Житло', 'Розваги', 'Здоров\'я', 'Навчання', 'Інше'],
  income: ['Зарплата', 'Підробіток', 'Подарунок', 'Інше'],
};

export const formatMoney = (n) =>
  new Intl.NumberFormat('uk-UA', { style: 'currency', currency: 'UAH', maximumFractionDigits: 0 }).format(n);

export const currentMonth = () => new Date().toISOString().slice(0, 7);

export const calcStats = (transactions, month = currentMonth()) => {
  const list = transactions.filter((t) => t.date.startsWith(month));
  const income = list.filter((t) => t.type === 'income').reduce((s, t) => s + t.amount, 0);
  const expense = list.filter((t) => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  const byCategory = {};
  list.filter((t) => t.type === 'expense').forEach((t) => {
    byCategory[t.category] = (byCategory[t.category] || 0) + t.amount;
  });
  return { income, expense, savings: income - expense, byCategory };
};
