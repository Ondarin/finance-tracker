/** Браузерний API: localStorage (кеш даних для офлайн-режиму та налаштування). */
export class StorageService {
  constructor(prefix) {
    this.prefix = prefix;
  }
  get(key, fallback = null) {
    try {
      const raw = localStorage.getItem(`${this.prefix}:${key}`);
      return raw === null ? fallback : JSON.parse(raw);
    } catch {
      return fallback;
    }
  }
  set(key, value) {
    try {
      localStorage.setItem(`${this.prefix}:${key}`, JSON.stringify(value));
    } catch { /* сховище переповнене або недоступне */ }
  }
}
