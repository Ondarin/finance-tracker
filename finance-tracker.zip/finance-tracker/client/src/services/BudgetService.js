export class BudgetService {
  constructor(http, storage) {
    this.http = http;
    this.storage = storage;
  }
  async get() {
    try {
      const data = await this.http.get('/budget');
      this.storage.set('budget', data);
      return data;
    } catch (e) {
      const cached = this.storage.get('budget');
      if (e.network && cached) return cached;
      throw e;
    }
  }
  async save(budget) {
    const data = await this.http.put('/budget', budget);
    this.storage.set('budget', data);
    return data;
  }
}
