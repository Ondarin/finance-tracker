/** Доступ до даних транзакцій: REST API + кеш у localStorage як fallback. */
export class TransactionService {
  constructor(http, storage) {
    this.http = http;
    this.storage = storage;
  }
  async getAll() {
    try {
      const data = await this.http.get('/transactions');
      this.storage.set('transactions', data);
      return { data, offline: false };
    } catch (e) {
      const cached = this.storage.get('transactions');
      if (e.network && cached) return { data: cached, offline: true };
      throw e;
    }
  }
  create = (tx) => this.http.post('/transactions', tx);
  update = (id, tx) => this.http.put(`/transactions/${id}`, tx);
  remove = (id) => this.http.delete(`/transactions/${id}`);
}
