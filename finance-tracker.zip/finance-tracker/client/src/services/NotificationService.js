/** Браузерний API: Notifications — сповіщення про перевищення бюджету. */
export class NotificationService {
  get supported() {
    return 'Notification' in window;
  }
  get permission() {
    return this.supported ? Notification.permission : 'unsupported';
  }
  async requestPermission() {
    if (!this.supported) return 'unsupported';
    return Notification.requestPermission();
  }
  notify(title, body) {
    if (this.permission === 'granted') new Notification(title, { body });
  }
}
