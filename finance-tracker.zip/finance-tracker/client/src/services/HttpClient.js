/** Обгортка над Fetch API з уніфікованою обробкою помилок мережі та HTTP. */
export class HttpClient {
  constructor(baseUrl) {
    this.baseUrl = baseUrl;
  }

  async request(path, options = {}) {
    let response;
    try {
      response = await fetch(`${this.baseUrl}${path}`, {
        headers: { 'Content-Type': 'application/json' },
        ...options,
      });
    } catch {
      const err = new Error('Не вдалося з\'єднатися із сервером. Перевірте підключення.');
      err.network = true;
      throw err;
    }
    if (!response.ok) {
      let message = `Помилка сервера (${response.status})`;
      try {
        message = (await response.json()).message || message;
      } catch { /* тіло відповіді не є JSON */ }
      throw new Error(message);
    }
    return response.status === 204 ? null : response.json();
  }

  get = (p) => this.request(p);
  post = (p, body) => this.request(p, { method: 'POST', body: JSON.stringify(body) });
  put = (p, body) => this.request(p, { method: 'PUT', body: JSON.stringify(body) });
  delete = (p) => this.request(p, { method: 'DELETE' });
}
