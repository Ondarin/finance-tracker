/**
 * Мінімальний DI-контейнер: реєстрація фабрик за токеном та
 * ледача (singleton) ініціалізація залежностей.
 */
export class Container {
  #factories = new Map();
  #instances = new Map();

  register(token, factory) {
    this.#factories.set(token, factory);
    return this;
  }

  resolve(token) {
    if (this.#instances.has(token)) return this.#instances.get(token);
    const factory = this.#factories.get(token);
    if (!factory) throw new Error(`DI: сервіс "${String(token)}" не зареєстровано`);
    const instance = factory(this); // фабрика сама резолвить свої залежності
    this.#instances.set(token, instance);
    return instance;
  }
}

export const TOKENS = {
  Http: 'HttpClient',
  Storage: 'StorageService',
  Notifier: 'NotificationService',
  Transactions: 'TransactionService',
  Budget: 'BudgetService',
};
