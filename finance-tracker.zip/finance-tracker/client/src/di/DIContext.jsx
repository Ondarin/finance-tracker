import { createContext, useContext } from 'react';

const DIContext = createContext(null);

export const DIProvider = ({ container, children }) => (
  <DIContext.Provider value={container}>{children}</DIContext.Provider>
);

/** Хук отримання сервісу з контейнера за токеном. */
export const useService = (token) => {
  const container = useContext(DIContext);
  if (!container) throw new Error('useService має використовуватись всередині <DIProvider>');
  return container.resolve(token);
};
