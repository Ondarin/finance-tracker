import { Container, TOKENS } from './Container';
import { HttpClient } from '../services/HttpClient';
import { StorageService } from '../services/StorageService';
import { NotificationService } from '../services/NotificationService';
import { TransactionService } from '../services/TransactionService';
import { BudgetService } from '../services/BudgetService';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:4000/api';

/** Composition root: єдине місце, де зв'язуються реалізації. */
export const createContainer = () =>
  new Container()
    .register(TOKENS.Http, () => new HttpClient(API_URL))
    .register(TOKENS.Storage, () => new StorageService('finance-tracker'))
    .register(TOKENS.Notifier, () => new NotificationService())
    .register(TOKENS.Transactions, (c) => new TransactionService(c.resolve(TOKENS.Http), c.resolve(TOKENS.Storage)))
    .register(TOKENS.Budget, (c) => new BudgetService(c.resolve(TOKENS.Http), c.resolve(TOKENS.Storage)));

export { TOKENS };
