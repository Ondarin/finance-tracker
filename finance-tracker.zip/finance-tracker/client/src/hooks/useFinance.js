import { useCallback, useEffect, useMemo, useState } from 'react';
import { useService } from '../di/DIContext';
import { TOKENS } from '../di/Container';
import { calcStats } from '../utils';

/** Container-логіка: стан, завантаження, CRUD, перевірка бюджету. */
export const useFinance = () => {
  const txService = useService(TOKENS.Transactions);
  const budgetService = useService(TOKENS.Budget);
  const notifier = useService(TOKENS.Notifier);

  const [transactions, setTransactions] = useState([]);
  const [budget, setBudget] = useState({ monthlyLimit: 0, savingsGoal: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [offline, setOffline] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [{ data, offline }, b] = await Promise.all([txService.getAll(), budgetService.get()]);
      setTransactions(data);
      setBudget(b);
      setOffline(offline);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [txService, budgetService]);

  useEffect(() => { load(); }, [load]);

  const stats = useMemo(() => calcStats(transactions), [transactions]);

  const run = async (fn) => {
    try {
      setError(null);
      await fn();
      await load();
      return true;
    } catch (e) {
      setError(e.message);
      return false;
    }
  };

  const addTransaction = (tx) => run(async () => {
    await txService.create(tx);
    const after = calcStats([...transactions, { ...tx }]);
    if (budget.monthlyLimit && after.expense > budget.monthlyLimit && stats.expense <= budget.monthlyLimit) {
      notifier.notify('Бюджет перевищено', 'Витрати за місяць перевищили встановлений ліміт.');
    }
  });
  const updateTransaction = (id, tx) => run(() => txService.update(id, tx));
  const removeTransaction = (id) => run(() => txService.remove(id));
  const saveBudget = (b) => run(() => budgetService.save(b));

  return { transactions, budget, stats, loading, error, offline, reload: load,
    addTransaction, updateTransaction, removeTransaction, saveBudget };
};
