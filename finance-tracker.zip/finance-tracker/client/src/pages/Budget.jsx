import { useState, useEffect } from 'react';
import { useService } from '../di/DIContext';
import { TOKENS } from '../di/Container';
import BudgetProgress from '../components/BudgetProgress';
import '../styles/components/Page.scss';

export default function Budget({ budget, stats, saveBudget }) {
  const notifier = useService(TOKENS.Notifier);
  const [limit, setLimit] = useState(budget.monthlyLimit);
  const [goal, setGoal] = useState(budget.savingsGoal);
  const [perm, setPerm] = useState(notifier.permission);
  const [saved, setSaved] = useState(false);

  useEffect(() => { setLimit(budget.monthlyLimit); setGoal(budget.savingsGoal); }, [budget]);

  const submit = async (e) => {
    e.preventDefault();
    const ok = await saveBudget({ monthlyLimit: Number(limit), savingsGoal: Number(goal) });
    setSaved(ok);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <section className="page">
      <h1>Бюджет і заощадження</h1>
      <form className="page__card page__form" onSubmit={submit}>
        <label>Місячний ліміт витрат, ₴
          <input type="number" min="0" value={limit} onChange={(e) => setLimit(e.target.value)} />
        </label>
        <label>Ціль заощаджень, ₴
          <input type="number" min="0" value={goal} onChange={(e) => setGoal(e.target.value)} />
        </label>
        <button className="btn btn--primary" type="submit">Зберегти</button>
        {saved && <span className="page__ok">✔ Збережено</span>}
      </form>
      <div className="page__card">
        <BudgetProgress label="Витрачено" current={stats.expense} target={budget.monthlyLimit} />
        <BudgetProgress label="Заощаджено" current={stats.savings} target={budget.savingsGoal} inverse />
      </div>
      <div className="page__card">
        <h2>Сповіщення</h2>
        {perm === 'unsupported' && <p>Браузер не підтримує сповіщення.</p>}
        {perm === 'granted' && <p>✔ Сповіщення про перевищення бюджету увімкнено.</p>}
        {perm === 'denied' && <p>Сповіщення заблоковано в налаштуваннях браузера.</p>}
        {perm === 'default' && (
          <button className="btn" onClick={async () => setPerm(await notifier.requestPermission())}>
            Увімкнути сповіщення
          </button>
        )}
      </div>
    </section>
  );
}
