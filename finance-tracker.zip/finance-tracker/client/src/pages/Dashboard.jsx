import StatCard from '../components/StatCard';
import CategoryChart from '../components/CategoryChart';
import BudgetProgress from '../components/BudgetProgress';
import TransactionList from '../components/TransactionList';
import '../styles/components/Page.scss';

export default function Dashboard({ stats, budget, transactions, removeTransaction }) {
  return (
    <section className="page">
      <h1>Огляд за поточний місяць</h1>
      <div className="page__grid">
        <StatCard title="Доходи" value={stats.income} tone="positive" />
        <StatCard title="Витрати" value={stats.expense} tone="negative" />
        <StatCard title="Заощадження" value={stats.savings} tone={stats.savings >= 0 ? 'positive' : 'negative'} />
      </div>
      <div className="page__card">
        <BudgetProgress label="Місячний ліміт витрат" current={stats.expense} target={budget.monthlyLimit} />
        <BudgetProgress label="Ціль заощаджень" current={stats.savings} target={budget.savingsGoal} inverse />
      </div>
      <div className="page__card">
        <h2>Витрати за категоріями</h2>
        <CategoryChart data={stats.byCategory} />
      </div>
      <div className="page__card">
        <h2>Останні операції</h2>
        <TransactionList items={transactions.slice(0, 5)} onEdit={() => {}} onDelete={removeTransaction} />
      </div>
    </section>
  );
}
