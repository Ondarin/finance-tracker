import { useState } from 'react';
import TransactionForm from '../components/TransactionForm';
import TransactionList from '../components/TransactionList';
import '../styles/components/Page.scss';

export default function Transactions({ transactions, addTransaction, updateTransaction, removeTransaction }) {
  const [editing, setEditing] = useState(null);
  const [filter, setFilter] = useState('all');
  const shown = filter === 'all' ? transactions : transactions.filter((t) => t.type === filter);

  const handleUpdate = async (data) => {
    const ok = await updateTransaction(editing.id, data);
    if (ok) setEditing(null);
    return ok;
  };

  return (
    <section className="page">
      <h1>Транзакції</h1>
      <div className="page__card">
        <h2>{editing ? 'Редагування' : 'Нова операція'}</h2>
        {editing
          ? <TransactionForm key={editing.id} initial={editing} onSubmit={handleUpdate} onCancel={() => setEditing(null)} />
          : <TransactionForm onSubmit={addTransaction} />}
      </div>
      <div className="page__card">
        <div className="page__filters">
          {[['all', 'Усі'], ['income', 'Доходи'], ['expense', 'Витрати']].map(([v, l]) => (
            <button key={v} className={`btn ${filter === v ? 'btn--primary' : ''}`} onClick={() => setFilter(v)}>{l}</button>
          ))}
        </div>
        <TransactionList items={shown} onEdit={setEditing} onDelete={removeTransaction} />
      </div>
    </section>
  );
}
