import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import { DIProvider } from './di/DIContext';
import { createContainer } from './di';
import './styles/main.scss';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <DIProvider container={createContainer()}>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </DIProvider>
  </React.StrictMode>
);
