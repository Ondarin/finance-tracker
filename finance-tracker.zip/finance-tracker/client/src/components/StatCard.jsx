import { formatMoney } from '../utils';
import '../styles/components/StatCard.scss';

export default function StatCard({ title, value, tone = 'neutral' }) {
  return (
    <div className={`stat-card stat-card--${tone}`}>
      <span className="stat-card__title">{title}</span>
      <strong className="stat-card__value">{formatMoney(value)}</strong>
    </div>
  );
}
