import '../styles/components/ErrorMessage.scss';

export default function ErrorMessage({ message, onRetry }) {
  return (
    <div className="error-message" role="alert">
      <span>⚠ {message}</span>
      {onRetry && <button onClick={onRetry}>Повторити</button>}
    </div>
  );
}
