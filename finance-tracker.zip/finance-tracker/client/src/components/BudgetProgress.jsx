import { formatMoney } from '../utils';
import '../styles/components/BudgetProgress.scss';

export default function BudgetProgress({ label, current, target, inverse = false }) {
  const pct = target > 0 ? Math.min((current / target) * 100, 100) : 0;
  const over = !inverse && target > 0 && current > target;
  const done = inverse && target > 0 && current >= target;
  const state = over ? 'danger' : done ? 'success' : pct > 80 && !inverse ? 'warning' : 'ok';

  return (
    <div className="budget-progress">
      <div className="budget-progress__head">
        <span>{label}</span>
        <span>{formatMoney(Math.max(current, 0))} / {formatMoney(target)}</span>
      </div>
      <div className="budget-progress__track">
        <div className={`budget-progress__bar budget-progress__bar--${state}`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}
