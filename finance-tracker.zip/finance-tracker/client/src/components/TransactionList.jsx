import { formatMoney } from '../utils';
import '../styles/components/TransactionList.scss';

export default function TransactionList({ items, onEdit, onDelete }) {
  if (items.length === 0) return <p className="transaction-list__empty">Транзакцій не знайдено</p>;

  return (
    <ul className="transaction-list">
      {items.map((t) => (
        <li key={t.id} className="transaction-list__item">
          <div className="transaction-list__info">
            <strong>{t.description || t.category}</strong>
            <small>{t.category} · {t.date}</small>
          </div>
          <span className={`transaction-list__amount transaction-list__amount--${t.type}`}>
            {t.type === 'income' ? '+' : '−'}{formatMoney(t.amount)}
          </span>
          <div className="transaction-list__actions">
            <button aria-label="Редагувати" onClick={() => onEdit(t)}>✏️</button>
            <button aria-label="Видалити" onClick={() => onDelete(t.id)}>🗑️</button>
          </div>
        </li>
      ))}
    </ul>
  );
}
