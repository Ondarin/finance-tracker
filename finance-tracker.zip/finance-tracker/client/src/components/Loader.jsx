import '../styles/components/Loader.scss';

export default function Loader({ text = 'Завантаження…' }) {
  return (
    <div className="loader" role="status">
      <span className="loader__spinner" />
      <span>{text}</span>
    </div>
  );
}
