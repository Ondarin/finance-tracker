import { NavLink } from 'react-router-dom';
import '../styles/components/Navbar.scss';

const links = [
  { to: '/', label: 'Огляд' },
  { to: '/transactions', label: 'Транзакції' },
  { to: '/budget', label: 'Бюджет' },
];

export default function Navbar({ offline }) {
  return (
    <header className="navbar">
      <span className="navbar__logo">💰 Finance Tracker</span>
      <nav className="navbar__links">
        {links.map((l) => (
          <NavLink key={l.to} to={l.to} end className="navbar__link">{l.label}</NavLink>
        ))}
      </nav>
      {offline && <span className="navbar__badge">офлайн (кеш)</span>}
    </header>
  );
}
