import { formatMoney } from '../utils';
import '../styles/components/CategoryChart.scss';

/** Горизонтальна діаграма витрат за категоріями (без зовнішніх бібліотек). */
export default function CategoryChart({ data }) {
  const entries = Object.entries(data).sort((a, b) => b[1] - a[1]);
  const max = Math.max(...entries.map(([, v]) => v), 1);
  if (entries.length === 0) return <p className="category-chart__empty">Витрат за цей місяць ще немає</p>;

  return (
    <ul className="category-chart">
      {entries.map(([name, value]) => (
        <li key={name} className="category-chart__row">
          <span className="category-chart__name">{name}</span>
          <div className="category-chart__track">
            <div className="category-chart__bar" style={{ width: `${(value / max) * 100}%` }} />
          </div>
          <span className="category-chart__value">{formatMoney(value)}</span>
        </li>
      ))}
    </ul>
  );
}
