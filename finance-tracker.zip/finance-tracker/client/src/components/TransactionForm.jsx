import { useState } from 'react';
import { CATEGORIES } from '../utils';
import '../styles/components/TransactionForm.scss';

const empty = () => ({ type: 'expense', category: CATEGORIES.expense[0], amount: '', description: '', date: new Date().toISOString().slice(0, 10) });

export default function TransactionForm({ initial, onSubmit, onCancel }) {
  const [form, setForm] = useState(initial || empty());
  const [error, setError] = useState('');

  const change = (e) => {
    const { name, value } = e.target;
    setForm((f) => {
      const next = { ...f, [name]: value };
      if (name === 'type') next.category = CATEGORIES[value][0];
      return next;
    });
  };

  const submit = async (e) => {
    e.preventDefault();
    const amount = Number(form.amount);
    if (!amount || amount <= 0) return setError('Введіть суму більше нуля');
    setError('');
    const ok = await onSubmit({ ...form, amount });
    if (ok && !initial) setForm(empty());
  };

  return (
    <form className="transaction-form" onSubmit={submit}>
      <select name="type" value={form.type} onChange={change}>
        <option value="expense">Витрата</option>
        <option value="income">Дохід</option>
      </select>
      <select name="category" value={form.category} onChange={change}>
        {CATEGORIES[form.type].map((c) => <option key={c}>{c}</option>)}
      </select>
      <input name="amount" type="number" min="0" step="0.01" placeholder="Сума, ₴" value={form.amount} onChange={change} />
      <input name="description" placeholder="Опис" value={form.description} onChange={change} />
      <input name="date" type="date" value={form.date} onChange={change} required />
      <div className="transaction-form__actions">
        <button type="submit" className="btn btn--primary">{initial ? 'Зберегти' : 'Додати'}</button>
        {onCancel && <button type="button" className="btn" onClick={onCancel}>Скасувати</button>}
      </div>
      {error && <p className="transaction-form__error">{error}</p>}
    </form>
  );
}
