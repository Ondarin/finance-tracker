import { Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/Navbar';
import Loader from './components/Loader';
import ErrorMessage from './components/ErrorMessage';
import Dashboard from './pages/Dashboard';
import Transactions from './pages/Transactions';
import Budget from './pages/Budget';
import { useFinance } from './hooks/useFinance';

export default function App() {
  const finance = useFinance();

  return (
    <div className="app">
      <Navbar offline={finance.offline} />
      <main className="app__content">
        {finance.error && <ErrorMessage message={finance.error} onRetry={finance.reload} />}
        {finance.loading && finance.transactions.length === 0 ? (
          <Loader />
        ) : (
          <Routes>
            <Route path="/" element={<Dashboard {...finance} />} />
            <Route path="/transactions" element={<Transactions {...finance} />} />
            <Route path="/budget" element={<Budget {...finance} />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        )}
      </main>
    </div>
  );
}
